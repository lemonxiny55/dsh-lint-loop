# dsh-lint-loop

[![npm version](https://img.shields.io/npm/v/dsh-lint-loop)](https://www.npmjs.com/package/dsh-lint-loop)
[![CI](https://github.com/lemonxiny55/dsh-lint-loop/actions/workflows/ci.yml/badge.svg)](https://github.com/lemonxiny55/dsh-lint-loop/actions/workflows/ci.yml)

English | [中文](README.zh.md)

Zero-config lint feedback loop — a [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (`dsh`) plugin that closes the **edit → lint → fix** loop: the model edits a file, immediately sees the lint findings (rule, file:line:col, message, fixable), and can auto-repair them with one `lint_fix` call. Uses whatever the repo already has — eslint, biome, or ruff. No setup, no bundled linters.

## What the model gets

| Tool | Purpose |
|---|---|
| `lint_diagnostics` | Lint findings for one file (or all files the linters have seen), with rule, `file:line:col`, message, and a `fixable` flag; severity filter and `max` cap. **Call right after editing a file.** |
| `lint_workspace_errors` | All errors across files linted this session — the "what is broken right now" view. |
| `lint_fix` | **The killer feature** — runs the repo's own auto-fixer (`eslint --fix` / `biome check --write` / `ruff check --fix`) on ONE file, re-lints, and returns what changed (+added/-removed lines), remaining findings, and the linter used. Workspace-root files only. |

Plus an optional **auto-injected system prompt section** (`lint:findings`, order 75 — right after `lsp:diagnostics`): after the model writes/edits a file through the harness, the plugin subscribes to the `fs/observed` event, lints the file through its serial pool, and injects only the **new/changed** findings introduced by that edit — top 5 lines plus counts, never the whole workspace. Stale deltas expire (`sectionTtlMs`, default 30s). Set `autoInject: false` to disable and rely on the tools only.

## The loop

```
model edits file  ──►  dsh writes it (fs tool)
                        │
                        ▼ fs/observed event
        plugin lints the file with the repo's own linter
                        │
                        ▼ new/changed findings only
        delta injected into the prompt (or lint_diagnostics on demand)
                        │
                        ▼
        model reads "src/a.ts:12 no-unused-vars …"  ──►  lint_fix ──►  clean
```

## Zero configuration

The plugin probes the repo root for what is already there and routes by extension:

| Config found | Linter | Files |
|---|---|---|
| `eslint.config.{js,mjs,cjs,ts}` or `.eslintrc.{js,cjs,json,yml}` | eslint | `.ts .tsx .mts .cts .js .jsx .mjs .cjs` |
| `biome.json` / `biome.jsonc` | biome | same JS family |
| `ruff.toml` / `.ruff.toml` / `pyproject.toml` with `[tool.ruff]` | ruff | `.py .pyi` |

- **Multiple configs coexist?** JS-family files go to eslint by default; biome only when a biome config exists WITHOUT an eslint config. Force the set with the `linters` config key.
- **Repo-local installs work**: `npm i -D eslint` puts the binary in `node_modules/.bin` — the plugin resolves it before `PATH`.
- **Nothing configured?** The plugin stays quiet; calling a tool returns the init hint (`npx eslint --init` / `biome init` / ruff) instead of an error.
- **Config file changes** (adding `biome.json` mid-session, say) are observed and re-probed automatically.

Example (input → output):

```
lint_diagnostics { file: "src/extract.ts" }
# lint findings (1 error, 1 warning)
src/extract.ts:12:3   error  no-unused-vars  'foo' is defined but never used
src/store.ts:8:5      warn   semi            missing semicolon  [fixable]
```

The canonical JSON (rule, file, line, col, severity, message, fixable, linter) is what `execute` returns; the compact table above is the rendered view. And the fix:

```
lint_fix { file: "src/store.ts" }
# lint_fix (eslint) — src/store.ts
fixed: yes (+0/-1 lines)
remaining: none — file is clean
```

## Install

Requires `dsh` (any install path — npx, npm, or source) and Node ≥ 22. The linters themselves are NOT bundled — the plugin uses whatever the repo already has.

```sh
# from npm (prebuilt)
npx @deepseek-ai/dsh plugin --profile web add dsh-lint-loop

# or from a directory containing this checkout
npx @deepseek-ai/dsh plugin --profile web add ./dsh-lint-loop
```

Restart the Web UI (`npx @deepseek-ai/dsh web`) — startup logs confirm each tool:

```
[dsh-lint-loop] plugin loaded
[dsh-lint-loop] registered tool: lint_diagnostics
...
```

Missing a linter entirely? The tools say so, with the exact install command: `linter "eslint" is not installed or failed to run. Install it with: npm i -D eslint`.

## Using it

In a workspace session, ask the agent:

- "Edit `src/extract.ts`, then check it with lint_diagnostics." — the section may already have shown the findings.
- "Fix all the auto-fixable lint problems in src/store.ts." (`lint_fix`)
- "What lint errors exist right now?" (`lint_workspace_errors`)

## Configuration

Options are passed as the plugin row's `config` in the profile patch (or defaults are used if absent):

```yaml
# $DSH_HOME/profiles/<name>/cordis.patch.yml — a bare row overrides by id.
- id: lint-loop
  config:
    maxFindings: 30
    linters: [eslint, ruff]   # force; otherwise auto-detect
```

| Key | Default | Meaning |
|---|---|---|
| `autoInject` | `true` | Register the auto-injected findings section (and the `fs/observed` listener) |
| `maxFindings` | `50` | Hard cap on findings surfaced by tools and the injected section (token-cost guard) |
| `linters` | `[]` (auto) | Force which linters are usable (`eslint` / `biome` / `ruff`); unknown keys are warned |
| `linterPath` | `{}` | Per-linter binary override (`{eslint: …, biome: …, ruff: …}`); a path ending in `.js/.mjs/.cjs` runs under the current Node |
| `sectionTtlMs` | `30000` | How long an injected delta stays current (min 1000) |
| `timeoutMs` | `10000` | Per-run linter process timeout (min 1000); a timed-out run is killed and reported |

## Supported linters

- **eslint** (`--no-warn-ignored -f json`): flat config and legacy `.eslintrc`; versions that reject `--no-warn-ignored` (< 8.22) fall back automatically, remembered per repo.
- **biome** (`check --reporter=json`): both the ≥ 2 reporter shape (1-based line/column, CLI-relative string path) and the legacy byte-offset `span` shape; `format`/`organizeImports` diffs are NOT findings.
- **ruff** (`check --output-format=json`): 1-based positions; `fix` present → `fixable: true`; every violation is an error (ruff has no severities).

Rust (`clippy`), Go (`golangci-lint`), and friends are deliberately deferred — `linters.ts` + `parse.ts` are the seams where further linters plug in (command, args, JSON shape, install hint).

## How it works

- **Detection** (`src/detect.ts`): config-file probe per repo root, cached, invalidated when an observed event carries a linter config basename (`biome.json`, `pyproject.toml`, …). `pyproject.toml` counts as ruff only when it really contains `[tool.ruff]`.
- **Runner pool** (`src/runner.ts`): one serial lane per (root, linter) — a save storm queues instead of stampeding; each run is a one-shot spawn with capped stdout/stderr, killed at `timeoutMs` (SIGTERM → SIGKILL grace).
- **Findings store** (`src/manager.ts`): per-root manager keeps the last lint result per file (512-file soft cap); `lint_fix` reads the file before and after the fix run, summarizes the line diff, and re-lints for the authoritative remaining set.
- **Edit detection** (`src/section.ts`): the `fs/observed` listener only queues the file (sync, never throws); a debounced refresh lints and diffs against the per-file previous state — only new/changed findings reach the prompt, capped to the top 5.
- **Workspace resolution**: session cwd → walk up to the nearest `.git` (bounded), same as dsh-code-index. Files outside a repo are refused.
- **Token-cost awareness**: every surface — tool output and injected section — is capped by `maxFindings` (section: top 5); the injected view is a per-edit delta, not the workspace.

## Relationship to dsh-lsp-diagnostics

The two plugins are **complementary and coexist**: `dsh-lsp-diagnostics` covers compiler/type errors via language servers (section order 70), this plugin covers style/lint findings via the repo's linters (order 75). No LSP is booted here and no linter is bundled there — clean separation, no overlap.

## Known limitations

- `lint_workspace_errors` covers files linted **this session** (a file joins the set the first time `lint_diagnostics` checks it) — not a whole-repo batch scan.
- Biome's JSON reporter does not expose fixability — `fixable` is `false` for biome findings, but `lint_fix` still runs `biome check --write` and reports what actually changed.
- Ruff has no severities — all ruff findings surface as `error`.
- Auto-injection triggers on harness file events; direct out-of-band edits (the user editing files externally) are not observed until the tool is called.
- Linters must be installed (repo-local `node_modules/.bin` is resolved first, then `PATH`, then `linterPath`); nothing is bundled, by design.
- Developer-preview harness: expect breaking harness/plugin API changes upstream.

## Development

```sh
pnpm install
pnpm test        # vitest — detection/routing/parsers/tools/fix/lifecycle against a marker-driven fake linter
pnpm typecheck
pnpm build       # tsup → dist/index.js (ESM, external deps)

# probe real linters in a real repo (any checkout with eslint/biome/ruff installed)
node scripts/probe-linter.mjs /path/to/repo src/someFile.ts
```

The suite runs against `tests/helpers/fakeLinter.mjs` — a marker-driven fake (`// lint: <severity> <rule> <message>`) that emits each REAL linter's JSON shape (eslint array, biome diagnostics with 1-based start/end or byte-offset spans, ruff array) and simulates auto-fix by stripping `[fixable]` marker comments — so no real linter is needed in CI. The real eslint 10 / biome 2.5 / ruff 0.16 output shapes were captured and regression-tested via `scripts/probe-linter.mjs`.

## Feedback

Found a bug, or want another linter next? Please [open an issue](https://github.com/lemonxiny55/dsh-lint-loop/issues).

## License

MIT. Not affiliated with DeepSeek; built on the public `dsh` plugin surface.
